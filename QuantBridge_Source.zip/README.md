# QuantBridge

QuantBridge serves portfolio risk and security research from a common SQLite snapshot. Researchers can compare funds, change a volatility window, add a holding and review gaps in its price history. The interface, clarification questions and coverage decisions use English by default. Both views use the same metric contract.

## Data and measures

The October 21, 2026 snapshot contains 613 holding records from IVV and OEF and 1,430 daily observations across ten stocks and SPY. Fund weights use the market value of U.S. dollar equity holdings. Stock returns and volatility use split- and dividend-adjusted closing prices. SPY supplies the observed trading calendar. A 20-session calculation requires 21 consecutive prices, and a 60-session calculation requires 61. An incomplete window leaves the affected metric blank.

The [metric contract](contracts/real_stage1.json) specifies the definitions. The [source manifest](data/real/2026-10-23/source_manifest.json) identifies the inputs and records their hashes. The snapshot supports retrospective analysis.

## Run the workbench

Use Python 3.14 with its standard library. Run the commands from the directory containing this file. The project starts on the loopback interface.

To use the October 21, 2026 acceptance data, place the corresponding SQLite database and its build manifest under `data/`. The source manifest in this package identifies all 13 original files by URL and SHA-256. With the matching holdings and price files in `data/real/2026-10-23/raw/`, the database can be built locally.

```sh
python -B -m quantbridge.ingest_real --sources data/real/2026-10-23 --output data/quantbridge_real_stage1.sqlite
python -B -m quantbridge.server
```

Open http://127.0.0.1:8765/ to compare funds or run a security comparison. The second consumer can also export CSV.

```sh
python -B -m quantbridge.research NVDA JPM --windows 20,60
```

For a fresh public-data run, download a new source folder first. Use an empty directory and a fresh copy of the package. Dates, holdings and reference results depend on the downloaded snapshot.

```sh
python -B -m quantbridge.fetch_real --directory data/real/new
python -B -m quantbridge.ingest_real --sources data/real/new --output data/quantbridge_real_stage1.sqlite
python -B -m quantbridge.server
```

## Natural-language queries

Set the server environment variables `QUANTBRIDGE_AI_PROVIDER=deepseek` and `DEEPSEEK_API_KEY` using a locally provisioned account. The model defaults to `deepseek-flash`. The assistant asks its questions in English, including when the original request is in another language. Restart the service and open http://127.0.0.1:8765/assistant. Each question can make up to three requests billed to that API account. A query may inspect definitions and requested securities' coverage before running a calculation. Prices, holdings values and calculations stay in the local service.

Try asking for fund risk. Once the assistant clarifies the measure, compare concentration in IVV and OEF with 20-session NVDA volatility. Then change the window to 60 sessions and add JPM. Review the coverage decision before saving the revised result. Saved results are stored by content hash under `data/results/`.

## Reproduce the acceptance checks

With the accepted October snapshot and original files in place, run the command below. The reference results apply to this snapshot. Tests use offline fixtures for provider requests and the real snapshot for financial calculations.

```sh
python -B -m unittest discover -v -s evaluation
```

To run the billed three-turn acceptance case, configure the model account and run `python -B -m evaluation.verify_live_revision --report evaluation/results/live_revision.json` with a new report filename. The case records actual tool requests, replies and checks and saves the two confirmed results.

The holdings layout check accepts a CSV with `fund,position_id,symbol,industry,reported_value,as_of`. Position IDs follow the source row order starting at one for each fund. The check requests the amount unit, reconciles every position in cents and compares both consumers' results. Run `python -B -m quantbridge.holdings_layout --help` for the command.

## Independent data verification

To check the accepted October snapshot against the original holdings and price files, supply an existing temporary directory and a new report path.

```sh
python -B -m evaluation.verify_real_stage1 --sources data/real/2026-10-23 --database data/quantbridge_real_stage1.sqlite --scratch <temporary-directory> --report <new-report-path>
```

Holdings come from [iShares IVV](https://www.ishares.com/us/products/239726/ishares-core-sp-500-etf) and [iShares OEF](https://www.ishares.com/us/products/239723/ishares-sp-100-etf). [Yahoo Finance](https://in.help.yahoo.com/kb/adjusted-close-sln28256.html) describes the price adjustments used for stock returns.
