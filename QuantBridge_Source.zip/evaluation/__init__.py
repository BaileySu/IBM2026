"""Independent acceptance utilities. Keep outside future Agent tool access."""
